void LCD_Init(void);
void Start_DMA(uint32_t * source, uint32_t * destination, uint32_t count);
