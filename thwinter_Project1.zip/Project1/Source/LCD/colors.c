#include "colors.h"

COLOR_T black={0,0,0}, 
	white={255,255,255}, 
	red={255,0,0},
	green={0,255,0},
	blue={0,0,255},
	yellow={255,255,0},
	cyan={0,255,255},
	magenta={255,0,255},
	dark_red={123,0,0}, 
	dark_green={0,123,0},
	dark_blue={0,0,123},
	dark_yellow={123,123,0},
	dark_cyan={0,123,123},
	dark_magenta={123,0,123},
	orange={188,124,26},
	light_gray={110,110,110}, 
	dark_gray={48,48,48};
	
	